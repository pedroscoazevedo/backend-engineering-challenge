To run the aplication you just need to make a jar of the src folder, and then run the jar this way:

- java -jar <nameOfJar.jar> <FilePAth> <WindowSize>

Exemples :

C:\\Users\\Pedro\\testeUnbabel.txt 5
C:\\Users\\Pedro\\testeUnbabel.txt 12