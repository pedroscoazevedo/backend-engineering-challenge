package events;

import java.time.LocalDateTime;
import java.util.Date;

public class Event implements Comparable{
	
	private LocalDateTime dateTime;
	private String translationID;
	private int duration; 
	
	public Event(LocalDateTime dateTime, String translationID, int duration) {
		this.dateTime = dateTime;
		this.translationID = translationID;
		this.duration = duration;
	}
	
	public LocalDateTime getDateTime() {
		return dateTime;
	}
	public void setDateTime(LocalDateTime dateTime) {
		this.dateTime = dateTime;
	}
	public String getTranslationID() {
		return translationID;
	}
	public void setTranslationID(String translationID) {
		this.translationID = translationID;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}

	@Override
	public int compareTo(Object o) {
		
		int i = 0;
		
		if(o!= null && o instanceof Event) {
			Event e = (Event) o;
			if(this.getDateTime().isAfter(e.getDateTime())) {
				i=1;
			}
			if(this.getDateTime().isBefore(e.getDateTime())) {
				i=-1;
			}	
		}
		
		return i;
	}
}
