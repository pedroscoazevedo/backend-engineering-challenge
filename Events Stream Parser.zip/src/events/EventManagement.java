package events;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeSet;

public class EventManagement {
	
	public void printEvent (TreeSet<Event> eventList, int maxNumber) {
		
		Event firstEvent = eventList.first();
		
		int year = firstEvent.getDateTime().getYear();
		int month = firstEvent.getDateTime().getMonthValue();
		int day = firstEvent.getDateTime().getDayOfMonth();
		int hour = firstEvent.getDateTime().getHour();
		int minute = firstEvent.getDateTime().getMinute();
		
		LocalDateTime startDate = LocalDateTime.of(year,month,day,hour,minute);
		
		Event lastEvent = eventList.last();
		
		year = lastEvent.getDateTime().getYear();
		month = lastEvent.getDateTime().getMonthValue();
		day = lastEvent.getDateTime().getDayOfMonth();
		hour = lastEvent.getDateTime().getHour();
		minute = lastEvent.getDateTime().getMinute();
		
		LocalDateTime lastDate = LocalDateTime.of(year,month,day,hour,minute);
		lastDate = lastDate.plusMinutes(1); // in this way the last thing he prints is the first ocurrence of the last event
		
		HashMap<String, Integer> contador = new HashMap<String, Integer>();
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		
		for ( ; startDate.isBefore(lastDate) || startDate.isEqual(lastDate); startDate = startDate.plusMinutes(1)) {
			ArrayList<Integer> list = howManyLeft(startDate,eventList,contador,maxNumber);
			float total = 0;
			int size = list.size();
			for(Integer element: list){
				total = total + element;
			}
			total = size == 0 ? 0 : total/size;
	        String formatDateTime = startDate.format(formatter);
	        
			System.out.println("{\"date\": \"" + formatDateTime  + "\", \"average_delivery_time\": " + total + "}" );
		}
		
	}
	
	private ArrayList<Integer> howManyLeft(LocalDateTime startDate, TreeSet<Event> eventList, HashMap<String, Integer> contador, int maxNumber){
		
		ArrayList<Integer> list = new ArrayList<Integer>();
		
		for(Event event: eventList){
			if(startDate.isAfter(event.getDateTime()) || startDate.isEqual(event.getDateTime())){
				if(contador.get(event.getTranslationID()) != null && contador.get(event.getTranslationID()) < maxNumber){
					contador.put(event.getTranslationID(),contador.get(event.getTranslationID())+1);
					list.add(event.getDuration());
				}else if( contador.get(event.getTranslationID()) == null){
					contador.put(event.getTranslationID(),1);
					list.add(event.getDuration());
				}
			}
		}
		return list;
	}

}
