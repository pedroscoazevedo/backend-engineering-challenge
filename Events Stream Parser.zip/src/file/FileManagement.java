package file;

import java.io.BufferedReader;
import java.io.FileReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.TreeSet;
import java.util.stream.Stream;

import events.Event;
import events.EventManagement;


public class FileManagement {
	
	public TreeSet<Event> openFile(String path) {
		
		TreeSet<Event> dataParsed = new TreeSet<Event>();
		
		try (BufferedReader br = new BufferedReader(new FileReader(path))) {
			String data;
			while ((data = br.readLine()) != null) {
				dataParser(data, dataParsed);
			}
		}
		catch(NoSuchFileException e) {
			System.out.println("FILE NOT FOUND");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return dataParsed;
	}
	
	public void dataParser(String data, TreeSet<Event> dataParsed) {
		
		String data2 = data != null? data.substring(1,data.length()-1):""; //remove the "{" and the "}"
		HashMap<String, String> eventAttributes = parseEvent(data2.split(","));
		Event event = creatEvent(eventAttributes);
		dataParsed.add(event);
	}
	
	private HashMap<String, String> parseEvent(String[] event) {
		
		HashMap<String, String> dataEvent = new HashMap<>();
		
		for(String eventAttribute : event) {
			String[] attribute = eventAttribute.split(": ");
			String attribute1 = attribute[0].trim().indexOf("\"") != -1 ? 
					attribute[0].trim().substring(1,attribute[0].trim().length()-1):attribute[0].trim(); //remove the " if exists
			String attribute2 = attribute[1].trim().indexOf("\"") != -1 ? 
					attribute[1].trim().substring(1,attribute[1].trim().length()-1):attribute[1].trim(); //remove the " if exists
			dataEvent.put(attribute1,attribute2);
		}
		
		return dataEvent;
	}
	
	private Event creatEvent(HashMap<String, String> eventAttributes) {
		
		int duration = 0;
		LocalDateTime localDate;
		String translationID = eventAttributes.get("translation_id");

		try{
			duration = Integer.parseInt(eventAttributes.get("duration"));
			
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
		try{
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSS");

	        String date = eventAttributes.get("timestamp");

	        localDate = LocalDateTime.parse(date, formatter);
			
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
		Event event = new Event(localDate,translationID,duration);
		
		return event;
	}
}
