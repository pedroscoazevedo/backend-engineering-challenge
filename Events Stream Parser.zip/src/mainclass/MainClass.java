package mainclass;

import java.util.TreeSet;

import events.Event;
import events.EventManagement;
import file.FileManagement;

public class MainClass {
	
	public static void main(String arg[]) {
		
		String path = arg[0];
		int maxNumber = Integer.parseInt(arg[1]);
		FileManagement fm = new FileManagement();
		TreeSet<Event> event = fm.openFile(path);		
		new EventManagement().printEvent(event,maxNumber);
	}

}
